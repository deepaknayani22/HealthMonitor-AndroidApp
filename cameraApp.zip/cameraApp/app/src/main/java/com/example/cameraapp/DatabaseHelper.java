package com.example.cameraapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String TABLE_NAME = "SymptomsRatings";
    public static final String COLUMN_USERID = "UserId";
    public static final String[] SYMPTOMS = {
            "Nausea", "Headache", "Diarrhea", "Sore_throat", "Fever",
            "Muscle_ache", "Loss_of_smell_taste", "Cough",
            "Breathlessness", "Feeling_tired"
    };

    private static final String DATABASE_NAME = "symptoms.db";
    private static final int DATABASE_VERSION = 1;

    private static final String DATABASE_CREATE =
            "CREATE TABLE " + TABLE_NAME + "(" +
                    COLUMN_USERID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "Nausea INTEGER, " +
                    "Headache INTEGER, " +
                    "Diarrhea INTEGER, " +
                    "Sore_throat INTEGER, " +
                    "Fever INTEGER, " +
                    "Muscle_ache INTEGER, " +
                    "Loss_of_smell_taste INTEGER, " +
                    "Cough INTEGER, " +
                    "Breathlessness INTEGER, " +
                    "Feeling_tired INTEGER, " +
                    "Heart_rate INTEGER, " +          // Added this column
                    "Respiratory_rate INTEGER);";     // Added this column


    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(DATABASE_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
}
