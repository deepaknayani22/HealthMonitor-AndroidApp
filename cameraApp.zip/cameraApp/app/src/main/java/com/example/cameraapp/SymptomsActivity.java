
package com.example.cameraapp;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.Toast;
import android.database.Cursor;
import android.content.Intent;

public class SymptomsActivity extends AppCompatActivity {

    Spinner spinnerSymptoms;
    RatingBar ratingBar;
    private SymptomsDataSource dataSource;
    private int currentUserId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_symptoms);

        Intent intent = getIntent();
        int Heart_rate = intent.getIntExtra("HEART_VALUE", 0);  // 0 is a default value
        int Resp_rate = intent.getIntExtra("RESP_VALUE", 0);
        Log.d("IntentValues", Heart_rate + " "  + Resp_rate);

        spinnerSymptoms = findViewById(R.id.spinnerSymptoms);
        ratingBar = findViewById(R.id.ratingBar);
        Button btnSubmit = findViewById(R.id.btnSubmit);

        ArrayAdapter<CharSequence> adapter = new ArrayAdapter<>(this,
                R.layout.custom_spinner_dropdown_item,
                DatabaseHelper.SYMPTOMS);
        adapter.setDropDownViewResource(R.layout.custom_spinner_dropdown_item);
        spinnerSymptoms.setAdapter(adapter);

        dataSource = new SymptomsDataSource(this);
        dataSource.open();

        currentUserId = dataSource.getLastUserId() + 1; // Set the starting UserId

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String symptomSelected = spinnerSymptoms.getSelectedItem().toString().replace(" ", "_");


                int ratingValue = (int) ratingBar.getRating();

//                long result = dataSource.insertSymptomRating(currentUserId, symptomSelected, ratingValue);
                long result = dataSource.insertOrUpdateSymptomRating(currentUserId, symptomSelected, ratingValue, Heart_rate, Resp_rate);



                if (result != -1) {
                    Toast.makeText(SymptomsActivity.this, "Data saved successfully", Toast.LENGTH_SHORT).show();
//                    currentUserId++; // Increment UserId for the next submission
                    dataSource.logDatabase();
                } else {
                    Toast.makeText(SymptomsActivity.this, "Error saving data", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        dataSource.close();
        super.onDestroy();
    }

}

