package com.example.cameraapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

public class SymptomsDataSource {

    private SQLiteDatabase database;
    private DatabaseHelper dbHelper;

    public SymptomsDataSource(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public long insertSymptomRating(int userId, String symptom, int rating) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_USERID, userId);

        for (String s : DatabaseHelper.SYMPTOMS) {
            values.put(s.replace(" ", "_"), (s.equals(symptom) ? rating : 0));
        }

        return database.insert(DatabaseHelper.TABLE_NAME, null, values);
    }

//    public long insertOrUpdateSymptomRating(int userId, String symptom, int rating) {
//        // First, check if a row with the given userId already exists.
//        Cursor cursor = database.query(DatabaseHelper.TABLE_NAME,
//                new String[] { DatabaseHelper.COLUMN_USERID },
//                DatabaseHelper.COLUMN_USERID + " = ?",
//                new String[] { String.valueOf(userId) },
//                null, null, null);
//
//        ContentValues values = new ContentValues();
//
//        if (cursor != null && cursor.moveToFirst()) {
//            // A row with the given userId exists. Update it.
//            cursor.close();
//
//            // Prepare values for update
//            values.put(symptom.replace(" ", "_"), rating);
//
//            database.update(DatabaseHelper.TABLE_NAME, values, DatabaseHelper.COLUMN_USERID + " = ?", new String[]{String.valueOf(userId)});
//        } else {
//            // No row with the given userId exists. Insert a new one.
//            if (cursor != null) {
//                cursor.close();
//            }
//
//            values.put(DatabaseHelper.COLUMN_USERID, userId);
//            for (String s : DatabaseHelper.SYMPTOMS) {
//                values.put(s.replace(" ", "_"), (s.equals(symptom) ? rating : 0));
//            }
//
//            database.insert(DatabaseHelper.TABLE_NAME, null, values);
//        }
//        return 0;
//    }
public long insertOrUpdateSymptomRating(int userId, String symptom, int rating, int heartRate, int respRate) {
    // First, check if a row with the given userId already exists.
    Cursor cursor = database.query(DatabaseHelper.TABLE_NAME,
            new String[] { DatabaseHelper.COLUMN_USERID },
            DatabaseHelper.COLUMN_USERID + " = ?",
            new String[] { String.valueOf(userId) },
            null, null, null);

    ContentValues values = new ContentValues();

    if (cursor != null && cursor.moveToFirst()) {
        // A row with the given userId exists. Update it.
        cursor.close();

        // Prepare values for update
        values.put(symptom.replace(" ", "_"), rating);
        values.put("Heart_rate", heartRate);  // Update the heart rate
        values.put("Respiratory_rate", respRate);  // Update the respiratory rate

        return database.update(DatabaseHelper.TABLE_NAME, values, DatabaseHelper.COLUMN_USERID + " = ?", new String[]{String.valueOf(userId)});
    } else {
        // No row with the given userId exists. Insert a new one.
        if (cursor != null) {
            cursor.close();
        }

        values.put(DatabaseHelper.COLUMN_USERID, userId);
        for (String s : DatabaseHelper.SYMPTOMS) {
            values.put(s.replace(" ", "_"), (s.equals(symptom) ? rating : 0));
        }
        values.put("Heart_rate", heartRate);  // Add the heart rate
        values.put("Respiratory_rate", respRate);  // Add the respiratory rate

        return database.insert(DatabaseHelper.TABLE_NAME, null, values);
    }


}



    public int getLastUserId() {
        String query = "SELECT MAX(" + DatabaseHelper.COLUMN_USERID + ") AS lastId FROM " + DatabaseHelper.TABLE_NAME;
        Cursor cursor = database.rawQuery(query, null);
        if (cursor != null && cursor.moveToFirst()) {
            int columnIndex = cursor.getColumnIndex("lastId");
            if(columnIndex != -1) {
                int lastId = cursor.getInt(columnIndex);
                cursor.close();
                return lastId;
            }
            cursor.close();
        }
        return 0; // Default to 0 if no data found or column not found
    }

public void logDatabase() {
    Cursor cursor = database.rawQuery("SELECT * FROM " + DatabaseHelper.TABLE_NAME + ";", null);

    if (cursor.moveToFirst()) {
        do {
            StringBuilder rowData = new StringBuilder();
            for (int i = 0; i < cursor.getColumnCount(); i++) {
                rowData.append(cursor.getColumnName(i)).append(" = ").append(cursor.getString(i)).append("; ");
            }
            Log.d("DatabaseLogRows", rowData.toString());
        } while (cursor.moveToNext());
    }

    cursor.close();
}

}
